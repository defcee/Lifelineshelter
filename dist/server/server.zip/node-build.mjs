import "dotenv/config";
import path from "path";
import { fileURLToPath } from "url";
import express from "express";
import cors from "cors";
import { Resend } from "resend";
const handleDemo = (req, res) => {
  const response = {
    message: "Hello from Express server"
  };
  res.status(200).json(response);
};
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
function generateToken(username) {
  return Buffer.from(`${username}:${Date.now()}`).toString("base64");
}
const handleAdminLogin = (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: "Username and password are required"
    });
  }
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    const token = generateToken(username);
    return res.status(200).json({
      success: true,
      message: "Login successful",
      token,
      admin: {
        username,
        email: process.env.ADMIN_EMAIL
      }
    });
  }
  res.status(401).json({
    success: false,
    message: "Invalid username or password"
  });
};
const handleAdminDashboard = (req, res) => {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) {
    return res.status(401).json({
      authenticated: false,
      message: "No authorization token provided"
    });
  }
  try {
    const decoded = Buffer.from(token, "base64").toString("utf-8");
    const [username] = decoded.split(":");
    res.status(200).json({
      authenticated: true,
      message: "Authenticated",
      user: { username }
    });
  } catch {
    res.status(401).json({
      authenticated: false,
      message: "Invalid or expired token"
    });
  }
};
const EMAIL_TO = process.env.CONTACT_EMAIL || "customerrepresentative@lifelineshelter.com";
const resend = new Resend(process.env.RESEND_API_KEY);
const handleGetInvolved = async (req, res) => {
  const { firstName, lastName, email, type, message } = req.body || {};
  if (!firstName || !lastName || !email || !type || !message) {
    return res.status(400).json({ message: "All fields are required." });
  }
  try {
    if (!process.env.RESEND_API_KEY) {
      console.warn("⚠️ RESEND_API_KEY missing. Set it in .env.");
      return res.status(500).json({ message: "Email service is not configured." });
    }
    if (!process.env.FROM_EMAIL) {
      console.warn("⚠️ FROM_EMAIL missing. Set it in .env. Must be a verified sender.");
      return res.status(500).json({ message: "Sender email not configured." });
    }
    const bccEmails = process.env.BCC_EMAIL ? process.env.BCC_EMAIL.split(",").map((e) => e.trim()) : [];
    await resend.emails.send({
      from: process.env.FROM_EMAIL,
      // Must be verified in your Resend dashboard
      to: [EMAIL_TO],
      // must be an array
      bcc: bccEmails,
      // BCC addresses from .env
      replyTo: [email],
      // array format
      subject: `[LifeLine] New ${type} Submission from ${firstName} ${lastName}`,
      html: `
        <p><strong>Name:</strong> ${firstName} ${lastName}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Type:</strong> ${type}</p>
        <p><strong>Message:</strong><br>${message.replace(/\n/g, "<br>")}</p>
      `,
      text: `Name: ${firstName} ${lastName}
Email: ${email}
Type: ${type}
Message:
${message}`
    });
    res.status(200).json({ message: "Your message has been sent. Thank you!" });
  } catch (err) {
    console.error("Email send error:", err.message || err);
    res.status(500).json({
      message: "Failed to send email. Please try again later.",
      error: err.message || "Unknown error"
    });
  }
};
const __dirname$1 = path.dirname(fileURLToPath(import.meta.url));
function createServer() {
  const app2 = express();
  app2.use(cors());
  app2.use(express.json());
  app2.use(express.urlencoded({ extended: true }));
  app2.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping pong";
    res.json({ message: ping });
  });
  app2.get("/api/demo", handleDemo);
  app2.post("/api/admin/login", handleAdminLogin);
  app2.get("/api/admin/dashboard", handleAdminDashboard);
  app2.post("/api/get-involved", handleGetInvolved);
  app2.all("/api/:splat*", (_req, res) => {
    res.status(404).json({ error: "API endpoint not found" });
  });
  return app2;
}
const PORT = Number(process.env.PORT) || 3e3;
const app = createServer();
const spaPath = path.resolve(__dirname$1, "../spa");
app.use(express.static(spaPath));
app.get("*", (req, res) => {
  if (req.path.startsWith("/api/") || req.path.startsWith("/health")) {
    return res.status(404).json({ error: "API endpoint not found" });
  }
  res.sendFile(path.join(spaPath, "index.html"), (err) => {
    if (err) {
      console.error(`Error serving index.html from ${spaPath}:`, err.message);
      res.status(500).json({ error: "Failed to serve index.html" });
    }
  });
});
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📱 Frontend available at /`);
  console.log(`🔧 API available at /api/`);
});
process.on("SIGTERM", () => process.exit(0));
process.on("SIGINT", () => process.exit(0));
//# sourceMappingURL=node-build.mjs.map
